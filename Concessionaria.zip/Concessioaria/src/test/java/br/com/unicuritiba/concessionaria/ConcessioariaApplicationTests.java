package br.com.unicuritiba.concessionaria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConcessioariaApplicationTests {

	@Test
	void contextLoads() {
	}

}
